import random
import time

# Define the Tetris board dimensions
BOARD_WIDTH = 10
BOARD_HEIGHT = 20

# Define the shapes of Tetris blocks (using ASCII characters)
shapes = [
    ['**', '**'],   # Square
    ['****'],       # Line
    ['***', '*  '], # L-Shape
    ['***', '  *'], # Reverse L-Shape
    ['** ', ' **'], # S-Shape
    [' **', '** ']  # Z-Shape
]

# Function to print the current state of the board
def print_board(board):
    for row in board:
        print(''.join(row))

# Function to check if a piece can be placed at a position on the board
def can_place(board, shape, row, col):
    shape_height = len(shape)
    shape_width = len(shape[0])
    
    # Check if the piece fits within the board boundaries
    if row + shape_height > BOARD_HEIGHT or col + shape_width > BOARD_WIDTH:
        return False
    
    # Check if the positions on the board are empty
    for r in range(shape_height):
        for c in range(shape_width):
            if shape[r][c] == '*' and board[row + r][col + c] != ' ':
                return False
    
    return True

# Function to place a piece on the board
def place_piece(board, shape, row, col):
    shape_height = len(shape)
    shape_width = len(shape[0])
    
    for r in range(shape_height):
        for c in range(shape_width):
            if shape[r][c] == '*':
                board[row + r][col + c] = '*'

# Function to remove completed rows from the board
def remove_completed_rows(board):
    rows_to_remove = []
    for r in range(BOARD_HEIGHT):
        if all(board[r][c] == '*' for c in range(BOARD_WIDTH)):
            rows_to_remove.append(r)
    
    for r in rows_to_remove:
        del board[r]
        board.insert(0, [' ']*BOARD_WIDTH)

# AI function to play Tetris (more intelligent approach)
def ai_play_tetris():
    board = [[' ']*BOARD_WIDTH for _ in range(BOARD_HEIGHT)]
    current_shape = random.choice(shapes)
    current_col = BOARD_WIDTH // 2 - len(current_shape[0]) // 2
    
    while True:
        # Find the optimal row to place the piece
        best_row = 0
        best_score = float('-inf')
        best_board = None
        
        for row in range(BOARD_HEIGHT):
            if can_place(board, current_shape, row, current_col):
                # Create a copy of the board and simulate placing the piece
                test_board = [row[:] for row in board]
                place_piece(test_board, current_shape, row, current_col)
                remove_completed_rows(test_board)
                
                # Evaluate the board state based on simple heuristics
                holes = sum(1 for c in range(BOARD_WIDTH) for r in range(BOARD_HEIGHT) if test_board[r][c] == ' ' and r < BOARD_HEIGHT - 1 and test_board[r + 1][c] == '*')
                height = max(0, BOARD_HEIGHT - sum(1 for r in range(BOARD_HEIGHT) if all(test_board[r][c] == ' ' for c in range(BOARD_WIDTH))))
                score = -height - 2 * holes
                
                if score > best_score:
                    best_score = score
                    best_row = row
                    best_board = test_board
        
        # Place the piece on the optimal position found
        if best_board:
            board = best_board
            place_piece(board, current_shape, best_row, current_col)
            remove_completed_rows(board)
        
        # Choose the next shape
        current_shape = random.choice(shapes)
        current_col = BOARD_WIDTH // 2 - len(current_shape[0]) // 2
        
        # Print the board (comment this out for faster simulation)
        print_board(board)
        print()
        time.sleep(0.5)  # Adjust the speed of the game
        
        # End condition (here, we continue indefinitely)
        # Add your own logic for ending the game (e.g., reaching a certain score)

# Run the AI simulation
ai_play_tetris()
